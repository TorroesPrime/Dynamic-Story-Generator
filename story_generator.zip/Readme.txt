This is by no means anything I would call finished, but it is functional and at least demonstrates the idea and concept of the project. It was also an opportunity for me to stretch my limited programming muscles a bit and work with OOP. Something that my intro to programming class basically mentioned existed but didn't go into any great detail about. 

To use the program:

If you're reading this chances are you've already unzipped the files. Well all you need to do is run the Output2.py file. The rest is automatic. 

Feel free to follow the develop (AKA: My blunders to learn from) on Github at: https://github.com/TorroesPrime/Dynamic-Story-Generator