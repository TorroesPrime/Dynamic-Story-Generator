import random
from names_sm import *
class SpaceMarine(object):
    def __init__ (self, name, chapter, role, Stat_WS, Stat_BS, Stat_Strength, Stat_Tough, Stat_Agility, Stat_Int, Stat_Perc, Stat_WP, Stat_Fell):
    #def __init__ (self, name, chapter, role, hair_style, hair_color, eye_color, body_type, Stat_WS, Stat_BS, Stat_Strength, Stat_Tough, Stat_Agility, Stat_Int, Stat_Perc, Stat_WP, Stat_Fell):
        self.name = name
        self.chapter= chapter
        self.role=role
        #self.gender = gender
        #self.hair_style = hair_style
        #self.hair_color = hair_color
        #self.eye_color = eye_color
        #self.body_type = body_type
        self.Char_Stats = {'WS':0,'BS':0,'Strength':0,'Toughness':0,'Agility':0,'Int':0,'Perc':0,'WP':0,'Fellowship':0,}
        self.Stat_WS = Stat_WS
        self.Stat_BS = Stat_BS
        self.Stat_Strength = Stat_Strength
        self.Stat_Tough = Stat_Tough
        self.Stat_Agility = Stat_Agility
        self.Stat_Int = Stat_Int
        self.Stat_Perc = Stat_Perc
        self.Stat_WP = Stat_WP
        self.Stat_Fell = Stat_Fell
        self.Char_Stats['WS'] = int(Stat_WS)
        self.Char_Stats['BS'] = int(self.Stat_BS)
        self.Char_Stats['Strength'] = int(self.Stat_Strength)
        self.Char_Stats['Toughness'] = int(self.Stat_Tough)
        self.Char_Stats['Agility'] = int(self.Stat_Agility)
        self.Char_Stats['Int'] = int(self.Stat_Int)
        self.Char_Stats['Perc'] = int(self.Stat_Perc)
        self.Char_Stats['WP'] = int(self.Stat_WP)
        self.Char_Stats['Fellowship'] = int(self.Stat_Fell)
        
    def CharSheet(self):
        print('Name:            '+self.name)
        print('Chapter:         '+self.chapter)
        print('Role:            '+self.role)
        print('Weapon Skill:    '+str(self.Stat_WS))
        print('Ballistic Skill: '+str(self.Stat_BS))
        print('Strength:        '+str(self.Stat_Tough))
        print('Agility:         '+str(self.Stat_Agility))
        print('Intelligence:    '+str(self.Stat_Int))
        print('Perception:      '+str(self.Stat_Perc))
        print('Will Power:      '+str(self.Stat_WP))
        print('Fellowship:      '+str(self.Stat_Fell))

        
        def randomGenerate(self, name):
            if self.chapter == none:
                pass

    #def Test(self, checked):
    #    if checked in self.Char_Stats:
    #        roll = random.randint(1, 100)
    #        if self.Char_Stats[checked] > roll or roll == 1:
    #            DoS= (self.Char_Stats[checked]-roll)%10
    #            print("{} succeeded their {} check with a {} and got {} degrees of success!".format(self.name, checked, roll, DoS))
    #            return 
    #        else:
    #            print("{} failed their {} check with a {}...".format(self.name, checked, roll))
    #    else:
    #            print("{} doesn't have that stat.  Check your typos.".format(self.name))

    def Test(self, checked, degree):
        if checked in self.Char_Stats:
            roll = random.randint(1, 100)
            print("{} is attempting a {} check. Using their base value of {} with a modifer of {}.".format(self.name, checked, self.Char_Stats[checked], degree))
            print('The roll resulted in a {}.'.format(roll))
            if self.Char_Stats[checked]+int(degree) > roll or roll == 1:
                DoS= int((self.Char_Stats[checked]-roll)/10)
                print("{} succeeded their {} check with a {} and got {} degrees of success!".format(self.name, checked, roll, DoS))
                return 
            else:
                print("{} failed their {} check with a {}...".format(self.name, checked, roll))
        else:
                print("{} doesn't have that stat.  Check your typos.".format(self.name))

                                                                            


