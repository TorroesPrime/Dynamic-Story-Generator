from classes import *
SK_climb = skill('Climb','Stat_Strength',1,False,'''The characters ability to climb a surface.''')

print(SK_climb)
