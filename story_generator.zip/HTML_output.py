from SpaceMarine import *
from Characters import *
from story import *
import datetime

storyname =(SM_01.name+' of the '+SM_01.chapter+'s in the Emperor\'s Authority')
filename=(storyname+'.html')

output_file = open(filename,'w')
file_header = '''<!DOCTYPE html>
	<html lang='en'>
		<head>
			<title>'''+storyname+'''</title>
			<link rel="stylesheet" type='text/css' href='roster.css'>
		</head>
		<body>'''
output_file.write(file_header)
#def Paragraphs(self, content):
#    output_file.write('<p>'+content+'</p>')

#def close(self):
#        output_file.write('</body></html>')
#        output_file.close()
#        print('Story compiled')
                        
    
    


        
