import os
from tkinter import *
import tkinter.messagebox
from tkinter import filedialog
from pygame import mixer
#https://youtu.be/bRQ5zMrpO-o?list=PLhTjy8cBISEp6lNKUO3iwbB1DKAkRwutl

root = Tk()


# create menu bar
menubar = Menu(root)
root.config(menu=menubar)
def browse_file():
    global filename
    filename = filedialog.askopenfilename()
    print(filename)
#create submenu
subMenu = Menu(menubar, tearoff=0)
menubar.add_cascade(label="File",menu=subMenu)
subMenu.add_command(label="Open", command = browse_file)
subMenu.add_command(label="Exit", command = root.destroy)

def about_us():
    tkinter.messagebox.showinfo('Our title','This is the info for the box to display')
subMenu = Menu(menubar, tearoff=0)
menubar.add_cascade(label="Help",menu=subMenu)
subMenu.add_command(label="About Us", command=about_us)

mixer.init() #initialize mixer


root.title("Music player")
root.iconbitmap(r'images/cv_e13_icon.ico')

text = Label(root,text="Let\'s make some noise!")
text.pack( pady=10)

lengthLabel = Label(root,text="Total Length- 00:00")
lengthLabel.pack( pady=10)

def show_details():
    text['text'] = 'Filename: '+os.path.basename(filename)
  
    a = mixer.sound(filename)
    total_length = a.get_length()
    print(total_length)


paused = FALSE

def play_music():
    global paused
    if paused:
        mixer.music.unpause()
        statusbar['text'] = 'Music Resumed'
        paused = FALSE
    else:
        try:
            mixer.music.load(filename)
            mixer.music.play()
            statusbar['text'] = 'Playing music: '+os.path.basename(filename)
            show_details()
        except:
            tkinter.messagebox.showerror('file not found','Melody could not find the file. Please check again.')


def stop_music():
    mixer.music.stop()
    statusbar['text'] = 'music stopped'
def pause_music():
    global paused
    paused = TRUE
    mixer.music.pause()
    statusbar['text'] = 'music paused'
def set_vol(val):
    volume = int(val)/100
    mixer.music.set_volume(volume)
def rewind_music():
    play_music()
    statusbar['text'] = 'music restarted'


muted = FALSE
def mute_music():
    global muted
    if muted:    #unmute the music
        MuteButton.configure(image=UnMutePhoto)
        scale.set(50)
        statusbar['text'] = 'Playing music: '+os.path.basename(filename)
        muted = FALSE
    else:
        MuteButton.configure(image=MutePhoto)
        scale.set(0)
        mixer.music.set_volume(0)
        muted = TRUE
        statusbar['text'] = 'MUTED'
    

middleFrame = Frame(root)
middleFrame.pack(padx=10, pady=3)

playPhoto = PhotoImage(file='images/play-button_32.png')
playButton = Button(middleFrame, image = playPhoto, command =play_music)
playButton.grid(row=0, column=0, pady=10, padx=3)

pausePhoto = PhotoImage(file='images/pause-button_32.png')
pauseButton = Button(middleFrame, image = pausePhoto, command =pause_music)
pauseButton.grid(row=0, column=1, padx=3)

stopPhoto = PhotoImage(file='images/cancel-button_32.png')
stopButton = Button(middleFrame, image = stopPhoto, command =stop_music)
stopButton.grid(row=0, column=2, padx=3)

bottomFrame = Frame(root)
bottomFrame.pack(padx=10, pady=3)

rewindPhoto = PhotoImage(file='images/rewind-button_32.png')
rewindButton = Button(bottomFrame, image = rewindPhoto, command =play_music)
rewindButton.grid()

scale = Scale(bottomFrame, from_=0, to =100, orient = HORIZONTAL, command =set_vol)
scale.set(50)
mixer.music.set_volume(.50)
#volume = 

scale.grid(row=0, column=2, pady=10)

UnMutePhoto = PhotoImage(file='images/unmute-button_32.png')
MutePhoto = PhotoImage(file='images/mute-button_32.png')
MuteButton = Button(bottomFrame, image = MutePhoto, command =mute_music)
MuteButton.grid(row=0, column=3, pady=10, padx=3)



welcome ="This is the variable"
statusbar = Label(root,text=welcome, relief = SUNKEN, anchor=W)
statusbar.pack(side= BOTTOM, fill = X)

root.mainloop()